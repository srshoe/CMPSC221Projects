/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pizzaservingscalc;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PizzaServingsCalc extends JFrame {

    private JLabel titleLabel;
    private JLabel promptLabel;
    private JTextField sizeTextField;
    private JButton calculateButton;
    private JLabel resultLabel;

    public PizzaServingsCalc() {
        setTitle("Pizza Servings Calculator");
        setLayout(new GridLayout(4, 1));

        titleLabel = new JLabel("Pizza Servings Calculator", JLabel.CENTER);
        titleLabel.setForeground(Color.RED);
        titleLabel.setFont(new Font("Serif", Font.BOLD, 26));
        add(titleLabel);

        JPanel line2 = new JPanel();
        promptLabel = new JLabel("Enter the size of the pizza in inches: ");
        sizeTextField = new JTextField(4);
        line2.add(promptLabel);
        line2.add(sizeTextField);
        add(line2); 

        calculateButton = new JButton("Calculate Servings");
        calculateButton.addActionListener(new CalculateServingsListener());
        add(calculateButton);

        resultLabel = new JLabel("", JLabel.CENTER);
        add(resultLabel);

        setSize(350, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    private class CalculateServingsListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            try {
                double size = Double.parseDouble(sizeTextField.getText());
                double servings = Math.pow(size / 8, 2); 

                resultLabel.setText(String.format("A %.0f inch pizza will serve %.2f people.", size, servings));
            } catch (NumberFormatException ex) {
                resultLabel.setText("Please enter a valid number!");
            }
        }
    }

    public static void main(String[] args) {
        new PizzaServingsCalc();
    }
}
