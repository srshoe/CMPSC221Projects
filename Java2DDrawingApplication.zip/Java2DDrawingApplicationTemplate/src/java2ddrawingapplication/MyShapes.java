package java2ddrawingapplication;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Point;
import java.awt.Stroke;

public abstract class MyShapes {
    private Point startPoint;
    private Point endPoint;
    private Paint paint;
    private Stroke stroke;

    public MyShapes() {
        this.startPoint = new Point();
        this.endPoint = new Point();
        this.stroke = new BasicStroke(5, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND);
        this.paint = Color.BLACK;
    }

    public MyShapes(Point pntA, Point pntB, Paint paint, Stroke strk) {
        this.startPoint = pntA;
        this.endPoint = pntB;
        this.paint = paint;
        this.stroke = strk;
    }

    public abstract void draw(Graphics2D g2d);

    public Point getStartPoint() {
        return startPoint;
    }

    public void setStartPoint(Point startPoint) {
        this.startPoint = startPoint;
    }

    public Point getEndPoint() {
        return endPoint;
    }

    public void setEndPoint(Point endPoint) {
        this.endPoint = endPoint;
    }

    public Paint getPaint() {
        return paint;
    }

    public void setPaint(Paint paint) {
        this.paint = paint;
    }

    public Stroke getStroke() {
        return stroke;
    }

    public void setStroke(Stroke stroke) {
        this.stroke = stroke;
    }

    // Method to set dashed stroke based on length
    public void setDashedStroke(float dashLength, float strokeWidth) {
        this.stroke = new BasicStroke(
            strokeWidth,
            BasicStroke.CAP_ROUND,
            BasicStroke.JOIN_ROUND,
            dashLength,
            new float[]{dashLength, dashLength}, // Dash pattern
            0 // Phase
        );
    }
}
