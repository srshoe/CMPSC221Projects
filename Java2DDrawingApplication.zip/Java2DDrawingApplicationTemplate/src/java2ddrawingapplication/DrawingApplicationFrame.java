package java2ddrawingapplication;

import java.awt.GradientPaint;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Point;
import java.awt.Stroke;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JColorChooser;
import javax.swing.JPanel;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JSpinner;
import javax.swing.BoxLayout;

public class DrawingApplicationFrame extends JFrame {
    // Create the panels for the top of the application.
    private JPanel topPanel;
    private JPanel firstLine;
    private JPanel secondLine;

    // Create the widgets for the firstLine Panel.
    private JComboBox<String> shapeSelector;
    private JButton undoButton;
    private JButton clearButton;
    private JButton firstColorButton;
    private JButton secondColorButton;

    // Create the widgets for the secondLine Panel.
    private JCheckBox filledCheckBox;
    private JCheckBox gradientCheckBox;
    private JCheckBox dashedCheckBox;
    private JSpinner strokeWidthSpinner;
    private JSpinner strokeDashLengthSpinner;

    // Variables for drawPanel.
    private DrawPanel drawPanel;
    private Color firstColor = Color.BLACK;
    private Color secondColor = Color.WHITE; // Default second color
    private String currentShape = "Line";
    private ArrayList<MyShapes> shapes = new ArrayList<>();

    // Add status label
    private JLabel statusLabel;

    // Constructor for DrawingApplicationFrame
    public DrawingApplicationFrame() {
        // Set up the frame
        setTitle("2D Drawing Application");
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Initialize panels
        topPanel = new JPanel();
        firstLine = new JPanel();
        secondLine = new JPanel();

        // Set layouts
        topPanel.setLayout(new BoxLayout(topPanel, BoxLayout.Y_AXIS)); // Stack panels vertically
        firstLine.setLayout(new FlowLayout(FlowLayout.CENTER)); // Center components in firstLine
        secondLine.setLayout(new FlowLayout(FlowLayout.CENTER)); // Center components in secondLine

        // Set the background color for the top panels
        topPanel.setBackground(Color.CYAN);
        firstLine.setBackground(Color.CYAN);
        secondLine.setBackground(Color.CYAN);

        // Create widgets for the firstLine Panel.
        shapeSelector = new JComboBox<>(new String[]{"Line", "Oval", "Rectangle"});
        firstColorButton = new JButton("1st Color...");
        secondColorButton = new JButton("2nd Color...");
        undoButton = new JButton("Undo");
        clearButton = new JButton("Clear");

        // Create widgets for the secondLine Panel.
        filledCheckBox = new JCheckBox("Filled");
        gradientCheckBox = new JCheckBox("Use Gradient");
        dashedCheckBox = new JCheckBox("Dashed");
        strokeWidthSpinner = new JSpinner();
        strokeDashLengthSpinner = new JSpinner();

        // Add widgets to firstLine
        firstLine.add(new JLabel("Shape:"));
        firstLine.add(shapeSelector);
        firstLine.add(firstColorButton);
        firstLine.add(secondColorButton);
        firstLine.add(undoButton);
        firstLine.add(clearButton);

        // Add widgets to secondLine
        secondLine.add(new JLabel("Options:"));
        secondLine.add(filledCheckBox);
        secondLine.add(gradientCheckBox);
        secondLine.add(dashedCheckBox);
        secondLine.add(new JLabel("Stroke Width:"));
        strokeWidthSpinner.setValue(5); // Default stroke width
        secondLine.add(strokeWidthSpinner);
        secondLine.add(new JLabel("Dash Length:"));
        strokeDashLengthSpinner.setValue(5); // Default dash length
        secondLine.add(strokeDashLengthSpinner);

        // Add panels to topPanel
        topPanel.add(firstLine);
        topPanel.add(secondLine);

        // Initialize draw panel
        drawPanel = new DrawPanel();

        // Initialize status label
        statusLabel = new JLabel("(0, 0)"); // Default coordinates
        statusLabel.setHorizontalAlignment(JLabel.LEFT); // Align left
        
        // Add topPanel to North, drawPanel to Center, and statusLabel to South
        add(topPanel, "North");
        add(drawPanel, "Center");
        add(statusLabel, "South");
        
        // Add listeners and event handlers
        firstColorButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                firstColor = JColorChooser.showDialog(null, "Choose First Color", firstColor);
            }
        });

        secondColorButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                secondColor = JColorChooser.showDialog(null, "Choose Second Color", secondColor);
            }
        });

        undoButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (!shapes.isEmpty()) {
                    shapes.remove(shapes.size() - 1); // Remove the last shape
                    drawPanel.repaint();
                }
            }
        });

        clearButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                shapes.clear(); // Clear all shapes
                drawPanel.repaint();
            }
        });

        shapeSelector.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                currentShape = (String) shapeSelector.getSelectedItem();
            }
        });

        // Set visible
        setVisible(true);
    }

    // Create a private inner class for the DrawPanel.
    private class DrawPanel extends JPanel {
        private Point startPoint;
        private Point endPoint;
        private MyShapes currentShapeBeingDrawn;

        public DrawPanel() {
            // Add mouse listener for drawing shapes
            addMouseListener(new MouseHandler());
            addMouseMotionListener(new MouseHandler());
        }

        public void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2d = (Graphics2D) g;

            // Loop through and draw each shape in the shapes ArrayList
            for (MyShapes shape : shapes) {
                shape.draw(g2d);
            }

            // If currently dragging, draw the shape being created
            if (currentShapeBeingDrawn != null) {
                currentShapeBeingDrawn.draw(g2d);
            }
        }

        private class MouseHandler extends MouseAdapter {
            @Override
            public void mousePressed(MouseEvent event) {
                startPoint = event.getPoint(); // Set starting point
                // Initialize a temporary shape with the current starting point
                currentShapeBeingDrawn = createShape(startPoint, startPoint);
            }

            @Override
            public void mouseDragged(MouseEvent event) {
                endPoint = event.getPoint(); // Update ending point
                if (currentShapeBeingDrawn != null) {
                    currentShapeBeingDrawn.setEndPoint(endPoint); // Update the end point of the temporary shape
                    drawPanel.repaint(); // Repaint to show the current shape being drawn
                }
            }

            @Override
            public void mouseReleased(MouseEvent event) {
                endPoint = event.getPoint(); // Finalize the ending point
                MyShapes newShape = createShape(startPoint, endPoint); // Create the actual shape
                if (newShape != null) {
                    shapes.add(newShape);
                    currentShapeBeingDrawn = null; // Clear the temporary shape
                    drawPanel.repaint();
                }
            }

            private MyShapes createShape(Point start, Point end) {
                Paint paint;
                float strokeWidth = (int) strokeWidthSpinner.getValue(); // Get stroke width from spinner
                float dashLength = (int) strokeDashLengthSpinner.getValue(); // Get dash length from spinner

                // Check if gradient is selected
                if (gradientCheckBox.isSelected()) {
                    paint = new GradientPaint(0, 0, firstColor, 50, 50, secondColor, true);
                } else {
                    paint = firstColor; // Use first color for simplicity
                }

                MyShapes shape = null;

                // Create the appropriate shape based on selection
                if (currentShape.equals("Line")) {
                    shape = new MyLine(start, end, paint, new BasicStroke(strokeWidth)); // Default stroke width
                } else if (currentShape.equals("Oval")) {
                    shape = new MyOval(start, end, paint, new BasicStroke(strokeWidth), filledCheckBox.isSelected());
                } else if (currentShape.equals("Rectangle")) {
                    shape = new MyRectangle(start, end, paint, new BasicStroke(strokeWidth), filledCheckBox.isSelected());
                }

                // Set dashed stroke if the checkbox is selected
                if (dashedCheckBox.isSelected() && shape != null) {
                    shape.setDashedStroke(dashLength, strokeWidth);
                }

                return shape;
            }

            @Override
            public void mouseMoved(MouseEvent event) {
                // Optional: Update status label with mouse coordinates
                Point mousePoint = event.getPoint();
                statusLabel.setText("(" + mousePoint.x + ", " + mousePoint.y + ")");
            }
        }
    }
}
