/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package loanaccount;

/**
 *
 * @author srsho
 */
public class LoanAccount {
    private double annualInterestRate;
    private double principal;
    private int months;
    
    public LoanAccount(double principal, double annualInterestRate, int months)
    {
        this.principal = principal;
        this.months = months;
        this.annualInterestRate = annualInterestRate;
    }
    public double calculateMonthlyPayment() {
        double result;
        double monthlyInterestRate = (annualInterestRate / 100) / 12;
        result = (principal * monthlyInterestRate) / (1 - Math.pow(1 + monthlyInterestRate, -months));
        return Math.round(result * 100.0) / 100.0;
    }
    public double getPrincipal() {
        return principal;
    }

    public void setPrincipal(double principal) {
        this.principal = principal;
    }

    public int getMonths() {
        return months;
    }

    public void setMonths(int months) {
        this.months = months;
    }

    public double getAnnualInterestRate() {
        return annualInterestRate;
    }

    public void setAnnualInterestRate(double annualInterestRate) {
        this.annualInterestRate = annualInterestRate;
    }
    @Override
    public String toString()
    {
        return "Principal: $" + principal +
           "\nAnnual Interest Rate: " + annualInterestRate + "%" +
           "\nTerm of Loan in Months: " + months +
           "\nMonthly Payment: $" + calculateMonthlyPayment() + "\n";
            
    }
    
    public static void main(String[] args)
    {
        // Create three different loan objects, one of each type.
       CarLoan carLoan = new CarLoan(25000.00, 4.25, 72, "IRQ3458977");
       Address propertyAddress = new Address("321 Main Street", "State College", "PA", "16801");
       PrimaryMortgage propertyLoan = new PrimaryMortgage(250000.00, 3.1, 360, 35.12, propertyAddress);
       UnsecuredLoan unsecuredLoan = new UnsecuredLoan(5000.00, 10.75, 48);
       System.out.format("%n%s%s%s%n", carLoan, propertyLoan, unsecuredLoan);
    }
}

