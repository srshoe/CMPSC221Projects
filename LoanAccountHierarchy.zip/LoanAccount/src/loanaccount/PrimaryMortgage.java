/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package loanaccount;

/**
 *
 * @author srsho
 */
public class PrimaryMortgage extends LoanAccount 
{
    private double PMIMonthlyAmount;
    private Address Address;
    public PrimaryMortgage(double principal, double annualInterestRate, int months, double PMIMonthlyAmount, Address Address)
    {
        super(principal, annualInterestRate, months);
        this.PMIMonthlyAmount = PMIMonthlyAmount;
        this.Address = Address;
    }   
    @Override
    public String toString() 
    {
        return "\nPrimary Mortgage Loan with:\n" + 
               super.toString() + 
               "PMI Monthly Amount: $" + PMIMonthlyAmount + "\n" +
               "Property Address: \n" + Address.toString() + "\n";
    }

}
