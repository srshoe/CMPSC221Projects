/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package loanaccount;

/**
 *
 * @author srsho
 */
public class LoanAccount {
    private static double annualInterestRate;
    private double principal;
    
    public LoanAccount(double principal)
    {
        this.principal = principal;
    }
    public double calculateMonthlyPayment(int numberOfPayments)
    {
        
        double monthlyInterest = (annualInterestRate / 100)/ 12;
        double monthlyPayment = principal * (monthlyInterest / (1 - Math.pow(1 + monthlyInterest, -numberOfPayments)));
        monthlyPayment = Math.round(monthlyPayment*100.0)/100.0;
        return monthlyPayment;
    }
    public static void setAnnualInterestRate(double newRate)
    {
        annualInterestRate = newRate;
    }
    public static double getAnnualInterestRate() {
        return annualInterestRate;
    }
    
    //helper method to print results
    public static void printMonthly (LoanAccount loan1, LoanAccount loan2)
    {
        double loan13Y = loan1.calculateMonthlyPayment(36);
        double loan15Y = loan1.calculateMonthlyPayment(60);
        double loan16Y = loan1.calculateMonthlyPayment(72);
        double loan23Y = loan2.calculateMonthlyPayment(36);
        double loan25Y = loan2.calculateMonthlyPayment(60);
        double loan26Y = loan2.calculateMonthlyPayment(72);
        double rate = getAnnualInterestRate();
        System.out.println("Monthly payments for loan1 of $5000.00 and loan2 $31000.00 for 3, 5, and 6 year loans at " + rate + "% interest.");
        System.out.println("Loan    3 years 5 years 6 years");
        System.out.println("Loan1   " + loan13Y + " " + loan15Y + " " + loan16Y);
        System.out.println("Loan2   " + loan23Y + " " + loan25Y + " " + loan26Y);
    }
    public static void main(String[] args)
    {
        LoanAccount loan1 = new LoanAccount(5000.00);
        LoanAccount loan2 = new LoanAccount(31000.00);
        setAnnualInterestRate(1.0);
        printMonthly(loan1, loan2);
        setAnnualInterestRate(5.0);
        System.out.println();
        printMonthly(loan1, loan2);
    }
}

