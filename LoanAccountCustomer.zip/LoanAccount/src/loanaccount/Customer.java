/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package loanaccount;

import java.util.ArrayList;

/**
 *
 * @author srsho
 */
public class Customer {
    private String firstName;
    private String lastName;
    private String SSN;
    private ArrayList<LoanAccount> loanAccounts;
    public Customer(String firstName, String lastName,String SSN)
    {
        this.firstName = firstName;
        this.lastName = lastName;
        this.SSN = SSN;
        this.loanAccounts = new ArrayList<>();
    }
    public String getFirstName()
    {
        return firstName;
    }
    public String getLastName()
    {
        return lastName;
    }
    public String getSSN()
    {
        return SSN;
    }
    public void addLoanAccount(LoanAccount account)
    {
        this.loanAccounts.add(account);
    }
    @Override
    public String toString()
    {
        String fullName = getFirstName() + " " + getLastName();
        return "Account Report for Customer: " + fullName + "with SSN: " + getSSN() + "\n"; 
    }
    public void printMonthlyReport()
    {
        System.out.print(this.toString());
        for (LoanAccount account : loanAccounts) 
        {
            System.out.println(account.toString());
        }
    }
}
