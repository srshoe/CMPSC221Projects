/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package functionalprogrammingtemplate;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 *
 * @author acv
 */
public class FunctionalProgrammingTemplate {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        // create the ArrayList of Invoices
        List<Invoice> invoices = List.of(
        new Invoice(83,"Electric sander", 7, 57.98),
        new Invoice(24,"Power saw", 18, 99.99),
        new Invoice(7,"Sledge hammer", 11, 21.50),
        new Invoice(77,"Hammer", 76, 11.99),
        new Invoice(39,"Lawn mower", 3, 79.50),
        new Invoice(68,"Screw driver", 106, 6.99),
        new Invoice(56,"Jig saw", 21, 11.00),
        new Invoice(3,"Wrench", 34, 7.50));
        
        //Display the table of invoices using Invoice toString().
        //Print table header.
        System.out.println("Part number\tPart description\tQuantity\tPrice per item\tValue");
        invoices.stream()
                .forEach(System.out::print);

        // a) Sort Invoice objects by partDescription, then display the results
        System.out.println("\nInvoices sorted by Part Description");
        invoices.stream()
                .sorted((inv1, inv2) -> inv1.getPartDescription().compareTo(inv2.getPartDescription()))
                .forEach(System.out::print);

        // b) Sort Invoice objects by pricePerItem, then display the results
        System.out.println("\nInvoices sorted by Price");
        invoices.stream()
                .sorted((inv1, inv2) -> Double.compare(inv1.getPricePerItem(), inv2.getPricePerItem()))
                .forEach(System.out::print);

        // c) Map each Invoice to partDescription and quantity, sort by quantity, then display the results
        System.out.println("\nPart Description and Qunatity for each Invoice");
        invoices.stream()
            .map(inv -> Map.of("Part Description", inv.getPartDescription(), "Quantity", inv.getQuantity()))
            .sorted((map1, map2) -> Integer.compare((int) map1.get("Quantity"), (int) map2.get("Quantity")))
            .forEach(map -> System.out.printf("%-16s %d%n", map.get("Part Description"), map.get("Quantity")));

        }

}
